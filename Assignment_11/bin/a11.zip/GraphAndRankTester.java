/* CS 314 STUDENTS: FILL IN THIS HEADER.
 *
 * Student information for assignment:
 *
 *  On my honor, RAHIK N SIKDER, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  UTEID:   rns2359
 *  email address: sikder.rahik@utexas.edu
 *  TA name: Casey, Assistant of Teachers
 */

/*
 * Questions.
 *
 * 1. The assignment presents three ways to rank teams using graphs.
 * The results, especially for the last two methods are reasonable.
 * However if all results from all college football teams are included
 * some unexpected results occur. Explain the unexpected results. You may
 * have to do some research on the various college football divisions to
 * make an informed answer. (What are the divisions within college
 * football? Who do teams play? How would this affect the basic
 * structure of the graph?)
 * 
 *  Typically college football is split into Divisions, which itself is split into 
 *  conferences. The divisons represent larger skill gaps and a team that's winning
 *  all their games in Divison 2 is not considered to be better than an average team
 *  int Division 1. The graph ranking algorithm, however, only takes into account the
 *  win loss ratio of any particular team, ignoring overall divisons and conference 
 *  placements (the latter of which is irrelavant for this explanation). The AP rankings
 *  take everything into account, and their top teams are taken solely from Division 1
 *  in their Divison 1 team poll (duh). When running the ranker with all teams against a
 *  human list, the graph algorithm with equate top teams of lower divisons with that of
 *  the higher divisons due to their win loss percentages being equals, pushing down the
 *  rankings of almost all division 1 teams overall. When the rankings are averaged out
 *  with the human poll, the pushed down rankings will bring down expected averages of most
 *  division 1 teams and boost the averages of the best division 2 teams despite the league
 *  of skill difference.
 * 
 *  To specifically answer sub questions : There are 4 footbal divisons outlined by
 *  the NCAA: Division 1 FBS, Division 1 FCS, Division 2, Division 3. Teams within each
 *  division are then split into seperate conferences within which games are played over 
 *  the year. At the end of a season, a number of experts and coaches fill out a poll that
 *  ranks each team within its division as a whole, and the top teams of the division play
 *  each other in post game bowl or champianship matches.
 * 
 *  This would affect the basic structure of the graph by adding in many more unconnected 
 *  subgraphs. A graph of division 1 would end of being connected as a few cross conference
 *  matches are played each year; however, cross divisional play is more rare.
 * 
 * 2. Suggest another way of method of ranking teams using the results
 * from the graph. Thoroughly explain your method. The method can build
 * on one of the three existing algorithms.
 * 
 * https://edstem.org/us/courses/42245/discussion/3941101 <- No need to answer
 *
 */

public class GraphAndRankTester {

    /**
     * Runs tests on Graph classes and FootballRanker class.
     * Experiments involve results from college football
     * teams. Central nodes in the graph are compared to
     * human rankings of the teams.
     * 
     * @param args None expected.
     */
    public static void main(String[] args) {
        runStudentTests();
    }

    // No fancy output this time, I want to just finish this :/
    private static void runStudentTests() {
        System.out.println("Student Graph Tests:\n");

        // Graph Edges
        String[][] testAEdges = {
                { "A", "B", "3" },
                { "A", "C", "1" },
                { "A", "E", "6" },
                { "B", "C", "4" },
                { "B", "D", "1" },
                { "D", "E", "1" },
                { "F", "G", "2" },
        };

        Graph testA = getGraph(testAEdges, false);

        // Test Dijkstras
        studentDijkstra(testA);

        // Test FindAllPaths
        studentFindAllPaths(testA);

        // Test Ranker
        studentRankers();

    }

    private static void studentDijkstra(Graph testA) {
        // Dijkstra Test #1
        testA.dijkstra("A");
        String actualPath = testA.findPath("E").toString();
        String expected = "[A, B, D, E]";
        System.out.print("Dijkstra Test #1 - ");
        if (actualPath.equals(expected)) {
            System.out.println("PASSED");
        } else {
            System.out.println("FAILED");
            System.out.println("Expected: " + expected + " actual " + actualPath);
        }

        // Dijkstra Test #2
        testA.dijkstra("F");
        actualPath = testA.findPath("G").toString();
        expected = "[F, G]";
        System.out.print("Dijkstra Test #2 - ");
        if (actualPath.equals(expected)) {
            System.out.println("PASSED");
        } else {
            System.out.println("FAILED");
            System.out.println("** Expected: " + expected + " actual " + actualPath + " **");
        }
        System.out.println("Path weighted cost: " + testA.getWeightedCostFromStart("G"));

        // Dijkstra Test #3
        testA.dijkstra("D");
        actualPath = testA.findPath("A").toString();
        expected = "[D, B, A]";
        System.out.print("Dijkstra Test #3 - ");
        if (actualPath.equals(expected)) {
            System.out.println("PASSED");
        } else {
            System.out.println("FAILED");
            System.out.println("** Expected: " + expected + " actual " + actualPath + " **");
        }
    }

    private static void studentFindAllPaths(Graph testA) {

        // Weighted
        String[] expectedPaths = {
                "Name: B                    cost per path: 2.5000, num paths: 4",
                "Name: D                    cost per path: 2.7500, num paths: 4",
                "Name: A                    cost per path: 3.2500, num paths: 4",
                "Name: E                    cost per path: 3.5000, num paths: 4",
                "Name: C                    cost per path: 4.0000, num paths: 4",
                "Name: F                    cost per path: 2.0000, num paths: 1",
                "Name: G                    cost per path: 2.0000, num paths: 1",
        };

        doAllPathsTests("Weighted Graph", testA, true, 3, 6, expectedPaths);

        // Unweighted
        expectedPaths = new String[] {
                "Name: A                    cost per path: 1.2500, num paths: 4",
                "Name: B                    cost per path: 1.2500, num paths: 4",
                "Name: C                    cost per path: 1.5000, num paths: 4",
                "Name: D                    cost per path: 1.5000, num paths: 4",
                "Name: E                    cost per path: 1.5000, num paths: 4",
                "Name: F                    cost per path: 1.0000, num paths: 1",
                "Name: G                    cost per path: 1.0000, num paths: 1",
        };

        doAllPathsTests("Unweighted Graph", testA, false, 2, 2, expectedPaths);

    }

    private static void studentRankers() {

        String actual = "2005ap_poll.txt";
        String gameResults = "div12005.txt";

        FootballRanker ranker = new FootballRanker(gameResults, actual);

        ranker.doUnweighted(true);
        ranker.doWeighted(true);
        ranker.doWeightedAndWinPercentAdjusted(true);

        System.out.println("\nTESTS ON FOOTBALL TEAM GRAPH WITH FootBallRanker CLASS: \n");
        double actualError = ranker.doUnweighted(false);
        if (actualError == 6.8) {
            System.out.println("Passed unweighted test");
        } else {
            System.out.println("FAILED UNWEIGHTED ROOT MEAN SQUARE ERROR TEST. Expected 6, actual: " + actualError);
        }

        actualError = ranker.doWeighted(false);
        if (actualError == 5.8) {
            System.out.println("Passed weigthed test");
        } else {
            System.out.println("FAILED WEIGHTED ROOT MEAN SQUARE ERROR TEST. Expected 12.6, actual: " + actualError);
        }

        actualError = ranker.doWeightedAndWinPercentAdjusted(false);
        if (actualError == 3.0) {
            System.out.println("Passed unweighted win percent test");
        } else {
            System.out.println("FAILED WEIGHTED  AND WIN PERCENT ROOT MEAN SQUARE ERROR TEST. Expected 6.3, actual: "
                    + actualError);
        }
    }

    private static void scottsTest() {
        graphTests();

        String actual = "2008ap_poll.txt";
        String gameResults = "div12008.txt";

        FootballRanker ranker = new FootballRanker(gameResults, actual);

        ranker.doUnweighted(true);
        ranker.doWeighted(true);
        ranker.doWeightedAndWinPercentAdjusted(true);

        System.out.println();
        doRankTests(ranker);
        System.out.println();
    }

    // tests on various simple Graphs
    private static void graphTests() {
        System.out.println("PERFORMING TESTS ON SIMPLE GRAPHS\n");
        graph0Tests();
        graph1Tests();
        graph2Tests();
        graph3Tests();
    }

    /*
     * The graph used here is the same one from the example
     * used to show Dijktra's algorithm from the slides on
     * Graphs. It may be useful to print out the priority queue
     * at the top of the main while loop in the dijktra method
     * to see if it matches the one in the slides. Note, the Java
     * PriorityQueue (which you CAN use in the dijkstra method)
     * breaks ties in an arbitrary manner, so the order of equal
     * elements in the priority queue may be different than those
     * shown in the slides. (And that is not a problem.)
     */
    private static void graph0Tests() {
        System.out.println("Graph #0 Tests:");
        // first a simple path test
        // Graph #0
        String[][] g1Edges = { { "A", "B", "1" },
                { "B", "C", "3" },
                { "A", "C", "7" },
                { "B", "D", "21" },
                { "C", "F", "3" },
                { "A", "G", "17" },
                { "D", "F", "4" },
                { "D", "G", "5" },
                { "D", "E", "6" } };
        Graph g1 = getGraph(g1Edges, false);

        g1.dijkstra("A");
        String actualPath = g1.findPath("E").toString();
        String expected = "[A, B, C, F, D, E]";
        if (actualPath.equals(expected)) {
            System.out.println("Passed dijkstra path test graph 0.");
        } else {
            System.out.println("Failed dijkstra path test graph 0. Expected: " + expected + " actual " + actualPath);
        }

        // now do all paths unweighted
        String[] expectedPaths = { "Name: D                    cost per path: 1.3333, num paths: 6",
                "Name: B                    cost per path: 1.5000, num paths: 6",
                "Name: A                    cost per path: 1.6667, num paths: 6",
                "Name: C                    cost per path: 1.6667, num paths: 6",
                "Name: F                    cost per path: 1.6667, num paths: 6",
                "Name: G                    cost per path: 1.6667, num paths: 6",
                "Name: E                    cost per path: 2.1667, num paths: 6" };
        doAllPathsTests("Graph 0", g1, false, 3, 3.0, expectedPaths);

        // now do all paths weighted
        expectedPaths = new String[] { "Name: F                    cost per path: 6.5000, num paths: 6",
                "Name: C                    cost per path: 7.0000, num paths: 6",
                "Name: D                    cost per path: 7.1667, num paths: 6",
                "Name: B                    cost per path: 8.5000, num paths: 6",
                "Name: A                    cost per path: 9.3333, num paths: 6",
                "Name: G                    cost per path: 11.3333, num paths: 6",
                "Name: E                    cost per path: 12.1667, num paths: 6" };
        doAllPathsTests("Graph 0", g1, true, 5, 17.0, expectedPaths);
    }

    private static void graph1Tests() {
        System.out.println("Graph #1 Tests:");
        // first a simple path test
        // Graph #1
        String[][] g1Edges = { { "A", "B", "1" },
                { "B", "C", "3" },
                { "B", "D", "12" },
                { "C", "F", "3" },
                { "A", "G", "7" },
                { "D", "F", "4" },
                { "D", "G", "5" },
                { "D", "E", "6" } };
        Graph g1 = getGraph(g1Edges, false);

        g1.dijkstra("A");
        String actualPath = g1.findPath("E").toString();
        String expected = "[A, B, C, F, D, E]";
        if (actualPath.equals(expected)) {
            System.out.println("Passed dijkstra path test graph 1.");
        } else {
            System.out.println("Failed dijkstra path test graph 1. Expected: " + expected + " actual " + actualPath);
        }

        // now do all paths unweighted
        String[] expectedPaths = { "Name: D                    cost per path: 1.3333, num paths: 6",
                "Name: B                    cost per path: 1.5000, num paths: 6",
                "Name: F                    cost per path: 1.8333, num paths: 6",
                "Name: G                    cost per path: 1.8333, num paths: 6",
                "Name: A                    cost per path: 2.0000, num paths: 6",
                "Name: C                    cost per path: 2.0000, num paths: 6",
                "Name: E                    cost per path: 2.1667, num paths: 6" };
        doAllPathsTests("Graph 1", g1, false, 3, 3.0, expectedPaths);

        // now do all paths weighted
        expectedPaths = new String[] { "Name: F                    cost per path: 6.5000, num paths: 6",
                "Name: C                    cost per path: 6.8333, num paths: 6",
                "Name: D                    cost per path: 7.1667, num paths: 6",
                "Name: B                    cost per path: 7.3333, num paths: 6",
                "Name: A                    cost per path: 7.8333, num paths: 6",
                "Name: G                    cost per path: 8.5000, num paths: 6",
                "Name: E                    cost per path: 12.1667, num paths: 6" };
        doAllPathsTests("Graph 1", g1, true, 5, 17.0, expectedPaths);
    }

    private static void graph2Tests() {
        System.out.println("Graph #2 Tests:");
        // first a simple path test
        // Graph #1
        String[][] g2Edges = { { "E", "G", "9.6" },
                { "G", "E", "19.2" },
                { "D", "F", "4.0" },
                { "F", "D", "8.0" },
                { "E", "B", "8.0" },
                { "B", "E", "16.0" },
                { "F", "A", "6.0" },
                { "A", "F", "12.0" },
                { "F", "C", "4.0" },
                { "C", "F", "8.0" },
                { "C", "E", "6.9" },
                { "E", "C", "13.8" },
                { "D", "G", "8.0" },
                { "G", "D", "16.0" },
                { "E", "A", "5.7" },
                { "A", "E", "11.4" },
                { "C", "A", "0.4" },
                { "A", "C", "0.8" },
                { "D", "A", "6.1" },
                { "A", "D", "12.2" },
                { "D", "B", "7.9" },
                { "B", "D", "15.8" },
                { "C", "G", "5.4" },
                { "G", "C", "10.8" },
                { "A", "B", "7.1" },
                { "B", "A", "14.2" },
                { "E", "F", "4.4" },
                { "F", "E", "8.8" } };
        Graph g2 = getGraph(g2Edges, true);

        // do all paths weighted
        String[] expectedPaths = new String[] { "Name: C                    cost per path: 6.8000, num paths: 6",
                "Name: A                    cost per path: 7.1333, num paths: 6",
                "Name: D                    cost per path: 7.6167, num paths: 6",
                "Name: F                    cost per path: 7.6833, num paths: 6",
                "Name: E                    cost per path: 7.7667, num paths: 6",
                "Name: G                    cost per path: 15.4667, num paths: 6",
                "Name: B                    cost per path: 16.8667, num paths: 6" };
        doAllPathsTests("Graph 2", g2, true, 3, 20.4, expectedPaths);
    }

    // Graph 3 is an unconnected Graph
    private static void graph3Tests() {
        System.out.println("Graph 3 Tests. Graph 3 is not fully connected. ");
        String[][] g3Edges = { { "A", "B", "13" },
                { "A", "C", "10" },
                { "A", "D", "2" },
                { "B", "E", "5" },
                { "C", "B", "1" },
                { "D", "C", "5" },
                { "E", "G", "1" },
                { "E", "F", "4" },
                { "F", "C", "3" },
                { "F", "E", "2" },
                { "G", "F", "2" },
                { "H", "I", "10" },
                { "H", "J", "5" },
                { "H", "K", "22" },
                { "I", "K", "3" },
                { "I", "J", "1" },
                { "J", "L", "8" } };
        Graph g3 = getGraph(g3Edges, true);

        // do all paths weighted
        String[] expectedPaths = { "Name: A                    cost per path: 10.0000, num paths: 6",
                "Name: D                    cost per path: 9.6000, num paths: 5",
                "Name: F                    cost per path: 3.0000, num paths: 4",
                "Name: E                    cost per path: 4.2500, num paths: 4",
                "Name: G                    cost per path: 4.2500, num paths: 4",
                "Name: C                    cost per path: 5.7500, num paths: 4",
                "Name: B                    cost per path: 7.5000, num paths: 4",
                "Name: H                    cost per path: 10.2500, num paths: 4",
                "Name: I                    cost per path: 4.3333, num paths: 3",
                "Name: J                    cost per path: 8.0000, num paths: 1" };
        doAllPathsTests("Graph 3", g3, true, 6, 16.0, expectedPaths);
    }

    // return a Graph based on the given edges
    private static Graph getGraph(String[][] edges, boolean directed) {
        Graph result = new Graph();
        for (String[] edge : edges) {
            result.addEdge(edge[0], edge[1], Double.parseDouble(edge[2]));
            // If edges are for an undirected graph add edge in other direction too.
            if (!directed) {
                result.addEdge(edge[1], edge[0], Double.parseDouble(edge[2]));
            }
        }
        return result;
    }

    // Tests the all paths method. Run each set of tests twice to ensure the Graph
    // is correctly reseting each time
    private static void doAllPathsTests(String graphNumber, Graph g, boolean weighted,
            int expectedDiameter, double expectedCostOfLongestShortestPath,
            String[] expectedPaths) {

        System.out.println("\nTESTING ALL PATHS INFO ON " + graphNumber + ". ");
        for (int i = 0; i < 2; i++) {
            System.out.println("Test run = " + (i + 1));
            System.out.println("Find all paths weighted = " + weighted);
            g.findAllPaths(weighted);
            int actualDiameter = g.getDiameter();
            double actualCostOfLongestShortesPath = g.costOfLongestShortestPath();
            if (actualDiameter == expectedDiameter) {
                System.out.println("Passed diameter test.");
            } else {
                System.out.println("FAILED diameter test. "
                        + "Expected = " + expectedDiameter +
                        " Actual = " + actualDiameter);
            }
            if (actualCostOfLongestShortesPath == expectedCostOfLongestShortestPath) {
                System.out.println("Passed cost of longest shortest path. test.");
            } else {
                System.out.println("FAILED cost of longest shortest path. "
                        + "Expected = " + expectedCostOfLongestShortestPath +
                        " Actual = " + actualCostOfLongestShortesPath);
            }
            testAllPathsInfo(g, expectedPaths);
            System.out.println();
        }

    }

    // Compare results of all paths info on Graph to expected results.
    private static void testAllPathsInfo(Graph g, String[] expectedPaths) {
        int index = 0;

        for (AllPathsInfo api : g.getAllPaths()) {
            if (expectedPaths[index].equals(api.toString())) {
                System.out.println(expectedPaths[index] + " is correct!!");
            } else {
                System.out.println("ERROR IN ALL PATHS INFO: ");
                System.out.println("index: " + index);
                System.out.println("EXPECTED: " + expectedPaths[index]);
                System.out.println("ACTUAL: " + api.toString());
                System.out.println();
            }
            index++;
        }
        System.out.println();
    }

    // Test the FootballRanker on the given file.
    private static void doRankTests(FootballRanker ranker) {
        System.out.println("\nTESTS ON FOOTBALL TEAM GRAPH WITH FootBallRanker CLASS: \n");
        double actualError = ranker.doUnweighted(false);
        if (actualError == 13.7) {
            System.out.println("Passed unweighted test");
        } else {
            System.out.println("FAILED UNWEIGHTED ROOT MEAN SQUARE ERROR TEST. Expected 13.7, actual: " + actualError);
        }

        actualError = ranker.doWeighted(false);
        if (actualError == 12.6) {
            System.out.println("Passed weigthed test");
        } else {
            System.out.println("FAILED WEIGHTED ROOT MEAN SQUARE ERROR TEST. Expected 12.6, actual: " + actualError);
        }

        actualError = ranker.doWeightedAndWinPercentAdjusted(false);
        if (actualError == 6.3) {
            System.out.println("Passed unweighted win percent test");
        } else {
            System.out.println("FAILED WEIGHTED  AND WIN PERCENT ROOT MEAN SQUARE ERROR TEST. Expected 6.3, actual: "
                    + actualError);
        }
    }
}
